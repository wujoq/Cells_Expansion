Zadanie zrobione na 16 punktów.
Brak sterowania z kamery, przełączania widoku do 3d oraz loggera.

Aby włączyć grę należy:
	1. zainstalowac biblioteke PySide6
		-pip install PySide6
	2. uruchomić main.py
		-windows python -m main
		-mac/linux python3 -m main